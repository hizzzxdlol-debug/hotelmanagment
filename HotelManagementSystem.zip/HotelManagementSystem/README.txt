HotelManagementSystem — учебный проект (Java 21)
IntelliJ IDEA: File -> Open -> папка HotelManagementSystem, JDK 21, src = Sources Root.
Запуск: открыть HotelManagementSystem.java, зелёный треугольник у main.
Консоль: mkdir out && javac -encoding UTF-8 -d out src/*.java && java -cp out HotelManagementSystem
