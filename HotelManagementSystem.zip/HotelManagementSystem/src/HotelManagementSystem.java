import java.util.Scanner;

public class HotelManagementSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // ===== Блок 1. Информация о гостинице (задачи 3-10) =====
        String hotelName = "Grand Astana Hotel";
        String hotelAddress = "г. Астана, пр. Республики, 15";
        String hotelPhone = "+7 (7172) 00-00-00";
        int totalRooms = 120;
        int availableRooms = 45;
        float hotelRating = 4.7f;          // рейтинг: float (см. таблицу типов данных)
        char hotelCategory = 'A';
        boolean isOpen = true;

        System.out.println("========== ИНФОРМАЦИЯ О ГОСТИНИЦЕ ==========");
        System.out.println("Название: " + hotelName);
        System.out.println("Адрес: " + hotelAddress);
        System.out.println("Телефон: " + hotelPhone);
        System.out.println("Всего номеров: " + totalRooms);
        System.out.println("Свободных номеров: " + availableRooms);
        System.out.println("Рейтинг: " + hotelRating);
        System.out.println("Категория: " + hotelCategory);
        System.out.println("Гостиница работает: " + isOpen);

        // ===== Блок 2. Информация о клиенте (задачи 11-17) =====
        System.out.println();
        System.out.println("---------- Регистрация клиента ----------");
        System.out.print("Введите ФИО клиента: ");
        String clientName = scanner.nextLine().trim();
        int clientAge = readInt(scanner, "Введите возраст клиента: ");
        String clientPassport = "TEST-1234567";   // учебные тестовые данные
        String clientPhone = "+7 (700) 123-45-67";
        double clientBalance = readDouble(scanner, "Введите баланс клиента: ");
        boolean isRegistered = true;

        System.out.println();
        System.out.println("============== АНКЕТА КЛИЕНТА ==============");
        System.out.println("ФИО: " + clientName);
        System.out.println("Возраст: " + clientAge);
        System.out.println("Документ: " + clientPassport);
        System.out.println("Телефон: " + clientPhone);
        System.out.println("Баланс: " + clientBalance);
        System.out.println("Зарегистрирован: " + isRegistered);

        // ===== Блок 3. Информация о номере (задачи 18-24) =====
        int roomNumber = 305;
        String roomType = "Deluxe";   // Standard, Deluxe, Lux
        double roomPrice = 25000.0;   // за сутки
        int roomFloor = 3;
        boolean hasWiFi = true;
        int bedCount = 2;
        char roomStatus = 'F';        // F - свободен, B - занят

        System.out.println();
        System.out.println("============== ИНФОРМАЦИЯ О НОМЕРЕ ==============");
        System.out.println("Номер комнаты: " + roomNumber);
        System.out.println("Тип: " + roomType);
        System.out.println("Цена за сутки: " + roomPrice);
        System.out.println("Этаж: " + roomFloor);
        System.out.println("Wi-Fi: " + hasWiFi);
        System.out.println("Кроватей: " + bedCount);
        System.out.println("Статус: " + roomStatus);

        // ===== Блок 4. Расчёты и бронирование (задачи 25-30) =====
        System.out.println();
        System.out.println("---------- Бронирование ----------");
        int daysOfStay = readInt(scanner, "Количество дней проживания: ");
        long bookingId = 100000000001L;    // идентификатор бронирования (long)

        double totalCost = roomPrice * daysOfStay;                       // задача 26
        double discount = readDouble(scanner, "Скидка в процентах (0-100): ");   // задача 27
        double finalCost = totalCost - totalCost * discount / 100;       // задача 28
        double paymentAmount = readDouble(scanner, "Внесённая оплата: "); // задача 29
        double debt = finalCost - paymentAmount;
        if (debt < 0) {
            debt = 0;
        }

        String bookingStatus;
        if (!isOpen || roomStatus != 'F') {
            bookingStatus = "Бронирование невозможно";
        } else if (debt == 0) {
            bookingStatus = "Подтверждено, оплачено полностью";
            roomStatus = 'B';
            availableRooms--;
        } else {
            bookingStatus = "Подтверждено, ожидается доплата";
            roomStatus = 'B';
            availableRooms--;
        }

        System.out.println();
        System.out.println("============== ОТЧЁТ О БРОНИРОВАНИИ ==============");
        System.out.println("ID бронирования: " + bookingId);
        System.out.println("Гостиница: " + hotelName);
        System.out.println("Клиент: " + clientName);
        System.out.println("Номер комнаты: " + roomNumber);
        System.out.println("Тип номера: " + roomType);
        System.out.println("Дней проживания: " + daysOfStay);
        System.out.println("Стоимость проживания: " + totalCost);
        System.out.println("Скидка: " + discount + "%");
        System.out.println("Итоговая сумма: " + finalCost);
        System.out.println("Внесённая оплата: " + paymentAmount);
        System.out.println("Остаток задолженности: " + debt);
        System.out.println("Статус бронирования: " + bookingStatus);
        System.out.println("Статус номера: " + roomStatus + ", свободных номеров: " + availableRooms);
        System.out.println("==================================================");

        scanner.close();
    }

    // Чтение целого числа с повтором при ошибке ввода
    private static int readInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите целое число.");
            }
        }
    }

    // Чтение дробного числа (допускается и точка, и запятая)
    private static double readDouble(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Double.parseDouble(scanner.nextLine().trim().replace(',', '.'));
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите число.");
            }
        }
    }
}
