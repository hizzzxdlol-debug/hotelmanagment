import java.util.Scanner;

public class Menu {
    private final Scanner scanner = new Scanner(System.in);
    private final DecisionSystem system = new DecisionSystem();
    private final Report report = new Report();

    public void run() {
        boolean running = true;
        while (running) {
            show();
            int choice = Validation.readInt(scanner, "Ваш выбор: ", 1, 3);
            switch (choice) {
                case 1 -> startWork();
                case 2 -> showInfo();
                case 3 -> {
                    report.print();
                    System.out.println("До свидания!");
                    running = false;
                }
            }
        }
    }

    private void show() {
        System.out.println("============================");
        System.out.println("       SMART DECISION");
        System.out.println("============================");
        System.out.println("1. Начать работу");
        System.out.println("2. Информация о системе");
        System.out.println("3. Выход");
        System.out.println("============================");
    }

    private void startWork() {
        int age = Validation.readInt(scanner, "Введите возраст (0-120): ", 0, 120);
        String decision = system.checkAge(age);
        report.add(age, decision);
    }

    private void showInfo() {
        System.out.println("Smart Decision — учебная система принятия решений.");
        System.out.println("Проверяет возраст: до 18 — доступ запрещен, 18-59 — разрешен, 60+ — пенсионная категория.");
    }
}
