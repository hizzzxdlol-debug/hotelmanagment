import java.util.ArrayList;
import java.util.List;

public class Report {
    private final List<String> records = new ArrayList<>();

    public void add(int age, String decision) {
        records.add("Возраст " + age + " -> " + decision);
    }

    public void print() {
        System.out.println("============================");
        System.out.println("       ИТОГОВЫЙ ОТЧЁТ");
        System.out.println("============================");
        if (records.isEmpty()) {
            System.out.println("Проверок не было.");
        } else {
            for (int i = 0; i < records.size(); i++) {
                System.out.println((i + 1) + ". " + records.get(i));
            }
            System.out.println("Всего проверок: " + records.size());
        }
        System.out.println("============================");
    }
}
