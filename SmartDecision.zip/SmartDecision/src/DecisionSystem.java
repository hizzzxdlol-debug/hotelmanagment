public class DecisionSystem {

    // Проверяет возраст, печатает решение и возвращает его текст.
    public String checkAge(int age) {
        String result;
        if (age < 18) {
            result = "Доступ запрещен";
        } else if (age < 60) {
            result = "Доступ разрешен";
        } else {
            result = "Пенсионная категория";
        }
        System.out.println(result);
        return result;
    }
}
