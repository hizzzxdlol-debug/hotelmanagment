SmartDecision — учебный проект (Java 21)

Открыть в IntelliJ IDEA: File -> Open -> выбрать папку SmartDecision,
затем File -> Project Structure -> Project SDK = JDK 21,
пометить папку src как Sources Root (ПКМ на src -> Mark Directory as -> Sources Root).
Запуск: открыть Main.java и нажать зелёный треугольник рядом с main.

Запуск из консоли (нужен JDK 21):
  mkdir out
  javac -encoding UTF-8 -d out src/*.java
  java -cp out Main
